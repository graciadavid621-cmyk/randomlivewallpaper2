package com.example.randomlivewallpaper

import android.app.Activity
import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.service.wallpaper.WallpaperService
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val services = packageManager.queryIntentServices(
            Intent(WallpaperService.SERVICE_INTERFACE),
            PackageManager.GET_META_DATA
        )

        val candidates = services
            .mapNotNull { it.serviceInfo }
            .filter { it.packageName != packageName }

        if (candidates.isEmpty()) {
            Toast.makeText(this, "No live wallpapers found", Toast.LENGTH_SHORT).show()
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            finish()
            return
        }

        val pick = candidates.random()
        val component = ComponentName(pick.packageName, pick.name)

        val preview = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, component)

        try {
            startActivity(preview)
        } catch (e: Exception) {
            // Fallback: open the system live wallpaper chooser
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
        finish()
    }
}
