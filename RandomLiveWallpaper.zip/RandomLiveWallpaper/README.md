# Random Live Wallpaper

Opens the preview screen of a random installed live wallpaper.

## Build the APK with GitHub Actions
1. Push this repo to GitHub (branch `main`).
2. Go to the **Actions** tab → **Build APK** (it runs on every push, or press **Run workflow**).
3. When it finishes, open the run and download the **RandomLiveWallpaper-debug** artifact. Unzip it to get `app-debug.apk`.
